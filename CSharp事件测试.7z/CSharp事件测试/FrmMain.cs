﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSharp事件测试
{
    public partial class FrmMain : Form
    {
        public FrmMain()
        {
            InitializeComponent();
        }
        #region btneventtest点击事件
        private void btneventtest_Click(object sender, EventArgs e)
        {
            MessageBox.Show("你点击了："+((Button)sender).Text+"按钮");//sender 就是事件的发送者，当想要使用事件发送者的属性时，需要将sender格式化为其相应格式，然后才能够调用其属性

           DialogResult intvalue= MessageBox.Show("这是弹窗内容", "这是弹窗标题内容",MessageBoxButtons.OKCancel,MessageBoxIcon.Question);
            //if (intvalue!= DialogResult.OK)
            //{
            //    MessageBox.Show("用户点击了取消按钮");
            //    return;
            //}
            //else
            //{
            //    MessageBox.Show("用户点击了确定按钮");
            //    return;
            //}
            switch (intvalue)
            {
                case DialogResult.OK:
                    MessageBox.Show("用户点击了确定操作");
                    break;
                case DialogResult.Cancel:
                    MessageBox.Show("用户点击了取消");
                    break ;
            }
            #endregion









        }

        private void BtnTeacher_Click(object sender, EventArgs e)
        {
            MessageBox.Show("这是"+((Button)sender).Text);

        }


    }
}
