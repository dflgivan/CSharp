﻿namespace CSharp事件测试
{
    partial class FrmMain
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmMain));
            this.btneventtest = new System.Windows.Forms.Button();
            this.btnAndy = new System.Windows.Forms.Button();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.BtnCarry = new System.Windows.Forms.Button();
            this.btnCOCO = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btneventtest
            // 
            resources.ApplyResources(this.btneventtest, "btneventtest");
            this.btneventtest.Name = "btneventtest";
            this.btneventtest.UseVisualStyleBackColor = true;
            this.btneventtest.Click += new System.EventHandler(this.btneventtest_Click);
            // 
            // btnAndy
            // 
            resources.ApplyResources(this.btnAndy, "btnAndy");
            this.btnAndy.ImageList = this.imageList1;
            this.btnAndy.Name = "btnAndy";
            this.btnAndy.UseVisualStyleBackColor = true;
            this.btnAndy.Click += new System.EventHandler(this.BtnTeacher_Click);
            // 
            // imageList1
            // 
            this.imageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "SysIco.ico");
            this.imageList1.Images.SetKeyName(1, "TABLE.ICO");
            this.imageList1.Images.SetKeyName(2, "turn.BMP");
            this.imageList1.Images.SetKeyName(3, "UserLogin.ico");
            this.imageList1.Images.SetKeyName(4, "UserPsw.ico");
            this.imageList1.Images.SetKeyName(5, "Users.ico");
            this.imageList1.Images.SetKeyName(6, "保存.bmp");
            this.imageList1.Images.SetKeyName(7, "查询选择.bmp");
            this.imageList1.Images.SetKeyName(8, "打印.BMP");
            this.imageList1.Images.SetKeyName(9, "关闭.bmp");
            this.imageList1.Images.SetKeyName(10, "计算.bmp");
            this.imageList1.Images.SetKeyName(11, "取消.bmp");
            this.imageList1.Images.SetKeyName(12, "删除.bmp");
            this.imageList1.Images.SetKeyName(13, "上记录.bmp");
            this.imageList1.Images.SetKeyName(14, "首记录.bmp");
            this.imageList1.Images.SetKeyName(15, "搜索.bmp");
            this.imageList1.Images.SetKeyName(16, "尾记录.bmp");
            this.imageList1.Images.SetKeyName(17, "下记录.bmp");
            this.imageList1.Images.SetKeyName(18, "新增.bmp");
            this.imageList1.Images.SetKeyName(19, "修改.bmp");
            // 
            // BtnCarry
            // 
            resources.ApplyResources(this.BtnCarry, "BtnCarry");
            this.BtnCarry.ImageList = this.imageList1;
            this.BtnCarry.Name = "BtnCarry";
            this.BtnCarry.UseVisualStyleBackColor = true;
            this.BtnCarry.Click += new System.EventHandler(this.BtnTeacher_Click);
            // 
            // btnCOCO
            // 
            resources.ApplyResources(this.btnCOCO, "btnCOCO");
            this.btnCOCO.Name = "btnCOCO";
            this.btnCOCO.UseVisualStyleBackColor = true;
            this.btnCOCO.Click += new System.EventHandler(this.BtnTeacher_Click);
            // 
            // FrmMain
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.Controls.Add(this.btnCOCO);
            this.Controls.Add(this.BtnCarry);
            this.Controls.Add(this.btnAndy);
            this.Controls.Add(this.btneventtest);
            this.MaximizeBox = false;
            this.Name = "FrmMain";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btneventtest;
        private System.Windows.Forms.Button btnAndy;
        private System.Windows.Forms.Button BtnCarry;
        private System.Windows.Forms.Button btnCOCO;
        private System.Windows.Forms.ImageList imageList1;
    }
}
