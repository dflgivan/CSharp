﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    internal class Teacher
    {
        public string teacherName { get; set; } 
        public int  teacherId { get; set; }
        private int teacherAge;
        public int TeacherAge
        {
           get { return teacherAge; }
            set { teacherAge = value; }
        }
    }
}
