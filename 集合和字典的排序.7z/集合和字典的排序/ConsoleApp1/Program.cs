﻿using System;
using System.Collections.Generic;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Student objStu1 = new Student(1000, "小明");
            Student objStu2 = new Student(1001, "小王");
            Student objStu3 = new Student(1002, "小光");
            Student objStu4 = new Student(1003, "小红");
           
            //创建集合对象
            List<Student> stuList = new List<Student>();
            stuList.Add(objStu1);
            stuList.Add(objStu2);
            stuList.Add(objStu3);
            stuList.Add(objStu4);
            stuList.Add((new Student()
            {
                StudentName="xiaoming",
                StudentAge=11,
                StudentId=12
            }));
            Console.WriteLine("元素总数： {0}",stuList.Count);
            stuList.Remove(objStu3);
            stuList.RemoveAt(0);//删除索引为0的数据
            stuList.Insert(0, new Student(1007,"小飞"));
            foreach (Student studentitem   in stuList)
            {
                Console.WriteLine(studentitem.StudentName);
            }
            List<Student> stuList2 = new List<Student>()
            {
                new Student(){StudentAge=18,StudentId=1},
                new Student(){StudentAge=18,StudentId=2},
            };
            foreach(Student studentitem in stuList2)
            {
                Console.WriteLine(studentitem.StudentAge);
                Console.WriteLine(studentitem.StudentId);
                Console.WriteLine(studentitem.StudentName) ;
            }
        }
    }
}
