﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp2
{
    class Student
    {
        public Student()
        {

        }
        public Student(int sstuId, string stuName)
        {
            this.StudentId = sstuId;
            this.StudentName = stuName;
        }
        public Student(int sstuId, string stuName, int stuAge) : this(sstuId, stuName)
        {
            this.StudentAge = stuAge;
        }
        public int StudentId { get; set; }
        public string StudentName { get; set; }
        public int StudentAge { get; set; }

    }
}
