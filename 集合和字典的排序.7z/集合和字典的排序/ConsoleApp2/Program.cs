﻿
using System;
using System.Collections.Generic;

namespace ConsoleApp2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Dictionary<string, Student> stus = new Dictionary<string, Student>();
            stus.Add("小张", new Student(666, "小zhang", 19));
            stus.Add("小明", new Student(678, "xiaoming",20));
            Console.WriteLine(stus["小明"].StudentName);
            foreach (string key  in stus.Keys)
            {
                Console.WriteLine(key);
            }
            foreach (Student value in stus.Values)
            {
                Console.WriteLine(value.StudentName);
            }
        }
    }
}
