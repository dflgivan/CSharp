﻿using System;


namespace 默认排序静态隐性显示
{
    internal class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
