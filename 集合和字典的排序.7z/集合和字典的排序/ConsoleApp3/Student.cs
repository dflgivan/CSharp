﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace 默认排序静态隐性显示
{
    class Student:IComparable<Student>
    {
        public Student()
        {

        }
        public Student(int sstuId, string stuName)
        {
            this.StudentId = sstuId;
            this.StudentName = stuName;
        }
        public Student(int sstuId, string stuName, int stuAge) : this(sstuId, stuName)
        {
            this.StudentAge = stuAge;
        }
        public int StudentId { get; set; }
        public string StudentName { get; set; }
        public int StudentAge { get; set; }

        public int CompareTo([AllowNull] Student other)
        {
   //实现接口自动生成的，此函数的语句标题不可随意改动，但内部语句可以根据不同的使用需求来做出改动
  // return this.StudentId.CompareTo(other.StudentId);//升序排列
  return other.StudentId.CompareTo(this.StudentId);//降序排列

            //这种方法只能够静态地从最开始写程序时直接确定程序的执行方案
        }

    }
    #region 4个排序类
    //添加4个排序类，并且分别实现排序接口
    class StuIdASC : IComparer<Student>
    {
        public int Compare([AllowNull] Student x, [AllowNull] Student y)
        {
return x.StudentId.CompareTo(y.StudentId);//x在前是升序排列，Y在前是降序排列
        }

    }
    class StuIdDESC : IComparer<Student>
    {
        public int Compare([AllowNull] Student x, [AllowNull] Student y)
        {
            return y.StudentId.CompareTo(x.StudentId);//x在前是升序排列，Y在前是降序排列
        }

    }
    class StuNameASC : IComparer<Student>
    {
        public int Compare([AllowNull] Student x, [AllowNull] Student y)
        {
            return x.StudentName.CompareTo(y.StudentName);//x在前是升序排列，Y在前是降序排列
        }

    }
    class StuNameDESC : IComparer<Student>
    {
        public int Compare([AllowNull] Student x, [AllowNull] Student y)
        {
            return y.StudentName.CompareTo(x.StudentName);//x在前是升序排列，Y在前是降序排列
        }

    }
    #endregion
}
