﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 默认排序线性显示
{
    internal class Student:IComparable<Student>
    {
        public Student()
        {

        }
        public Student(int sstuId, string stuName)
        {
            this.StudentId = sstuId;
            this.StudentName = stuName;
        }
        public Student(int sstuId, string stuName, int stuAge) : this(sstuId, stuName)
        {
            this.StudentAge = stuAge;
        }
        public int StudentId { get; set; }
        public string StudentName { get; set; }
        public int StudentAge { get; set; }

        int IComparable<Student>.CompareTo(Student? other)
        {
            //这种显示方法，是可以唯一的指定这个来自于IComparable的CompareTo方法
            throw new NotImplementedException();
        }
    }
    #region 4个排序类
    //添加4个排序类，并且分别实现排序接口
    class StuIdASC : IComparer<Student>
    {
        public int Compare([AllowNull] Student x, [AllowNull] Student y)
        {
            return x.StudentId.CompareTo(y.StudentId);//x在前是升序排列，Y在前是降序排列
        }

    }
    class StuIdDESC : IComparer<Student>
    {
        public int Compare([AllowNull] Student x, [AllowNull] Student y)
        {
            return y.StudentId.CompareTo(x.StudentId);//x在前是升序排列，Y在前是降序排列
        }

    }
    class StuNameASC : IComparer<Student>
    {
        public int Compare([AllowNull] Student x, [AllowNull] Student y)
        {
            return x.StudentName.CompareTo(y.StudentName);//x在前是升序排列，Y在前是降序排列
        }

    }
    class StuNameDESC : IComparer<Student>
    {
        public int Compare([AllowNull] Student x, [AllowNull] Student y)
        {
            return y.StudentName.CompareTo(x.StudentName);//x在前是升序排列，Y在前是降序排列
        }

    }
    #endregion
}
