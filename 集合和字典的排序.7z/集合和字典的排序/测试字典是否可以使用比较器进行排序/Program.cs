﻿using System;
using System.Collections.Generic;

namespace 测试字典是否可以使用比较器进行排序
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Dictionary<string, Student> stus = new Dictionary<string, Student>();
            stus.Add("小张", new Student(666, "小zhang", 19));
            stus.Add("小明", new Student(678, "xiaoming", 20));
            stus.Add("小飞", new Student(689, "xiaofei", 20));
            stus.Add("小王", new Student(567, "xiaowang", 21));
            Console.WriteLine(stus["小明"].StudentName);
            foreach (string key in stus.Keys)
            {
                Console.WriteLine(key);
            }
            foreach (Student value in stus.Values)
            {
                Console.WriteLine(value.StudentName);
            }
            stus.sort();
        }
    }
}
